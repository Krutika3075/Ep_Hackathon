


#include "stm32f407xx.h"
#include <stdint.h>

/* =========================================================
   SERVO
   ========================================================= */

void Servo_Init(void);

void Servo_SetAngle(uint8_t angle);

void Servo_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    GPIOA->MODER |= (2<<12);

    GPIOA->AFR[0] |= (2<<24);

    TIM3->PSC = 16 - 1;

    TIM3->ARR = 20000 - 1;

    TIM3->CCMR1 |= (6<<4);

    TIM3->CCER |= 1;

    TIM3->CCR1 = 1500;

    TIM3->CR1 |= 1;
}

void Servo_SetAngle(uint8_t angle)
{
    uint16_t pulse;

    pulse = 500 + ((angle * 2000)/180);

    TIM3->CCR1 = pulse;
}

/* =========================================================
   BUZZER
   ========================================================= */

void Buzzer_Init(void);

void Buzzer_On(void);

void Buzzer_Off(void);

void Buzzer_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;

    GPIOC->MODER &= ~(3<<10);

    GPIOC->MODER |= (1<<10);
}

void Buzzer_On(void)
{
    GPIOC->ODR |= (1<<5);
}

void Buzzer_Off(void)
{
    GPIOC->ODR &= ~(1<<5);
}


/* =========================================================
   STATUS LEDs
   ========================================================= */

void LEDs_Init(void);

void Obstacle_LED_ON(void);
void Obstacle_LED_OFF(void);

void Gas_LED_ON(void);
void Gas_LED_OFF(void);

void Environment_LED_ON(void);
void Environment_LED_OFF(void);

void Collision_LED_ON(void);
void Collision_LED_OFF(void);

void LEDs_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;

    /* PC8 OUTPUT */

    GPIOC->MODER &= ~(3<<16);

    GPIOC->MODER |= (1<<16);

    /* PD12 PD13 PD14 PD15 OUTPUT */

    GPIOD->MODER |= (1<<24);
    GPIOD->MODER |= (1<<26);
    GPIOD->MODER |= (1<<28);
    GPIOD->MODER |= (1<<30);
}

/* =========================================================
   OBSTACLE LED -> PD12
   ========================================================= */

void Obstacle_LED_ON(void)
{
    GPIOD->ODR |= (1<<12);
}

void Obstacle_LED_OFF(void)
{
    GPIOD->ODR &= ~(1<<12);
}

/* =========================================================
   GAS LED -> PD13
   ========================================================= */

void Gas_LED_ON(void)
{
    GPIOD->ODR |= (1<<13);
}

void Gas_LED_OFF(void)
{
    GPIOD->ODR &= ~(1<<13);
}

/* =========================================================
   ENVIRONMENT LED -> PD14
   ========================================================= */

void Environment_LED_ON(void)
{
    GPIOD->ODR |= (1<<14);
}

void Environment_LED_OFF(void)
{
    GPIOD->ODR &= ~(1<<14);
}

/* =========================================================
   COLLISION LED -> PD15
   ========================================================= */

void Collision_LED_ON(void)
{
    GPIOD->ODR |= (1<<15);
}

void Collision_LED_OFF(void)
{
    GPIOD->ODR &= ~(1<<15);
}
/* =========================================================
   FUEL LED -> PC8
   ========================================================= */

void Fuel_LED_ON(void);

void Fuel_LED_OFF(void);

void Fuel_LED_ON(void)
{
    GPIOC->ODR |= (1<<8);
}

void Fuel_LED_OFF(void)
{
    GPIOC->ODR &= ~(1<<8);
}
