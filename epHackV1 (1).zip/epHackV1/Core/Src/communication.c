

#include "stm32f407xx.h"
#include <stdint.h>

/* =========================================================
   EXTERNAL FUNCTIONS
   ========================================================= */

void UART2_SendString(char *str);

/* =========================================================
   BLUETOOTH HC05
   ========================================================= */

void Bluetooth_Init(void);

void Bluetooth_Send(char *str);

void Bluetooth_Init(void)
{
    /* UART2 ALREADY INITIALIZED */
}

void Bluetooth_Send(char *str)
{
    UART2_SendString(str);
}
