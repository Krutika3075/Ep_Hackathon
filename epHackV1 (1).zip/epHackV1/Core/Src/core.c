

#include "stm32f407xx.h"
#include <stdint.h>

/* =========================================================
   UART2
   ========================================================= */

void UART2_Init(void);

void UART2_SendChar(char c);

void UART2_SendString(char *str);

char UART2_ReadChar(void);

void UART2_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /* PA2 TX */
    /* PA3 RX */

    GPIOA->MODER &= ~(0xF << 4);

    GPIOA->MODER |= (0xA << 4);

    GPIOA->AFR[0] |= (7 << 8);

    GPIOA->AFR[0] |= (7 << 12);

    USART2->BRR = 0x0683;

    USART2->CR1 |= USART_CR1_TE;

    USART2->CR1 |= USART_CR1_RE;

    USART2->CR1 |= USART_CR1_UE;
}

void UART2_SendChar(char c)
{
    while(!(USART2->SR & USART_SR_TXE));

    USART2->DR = c;
}

void UART2_SendString(char *str)
{
    while(*str)
    {
        UART2_SendChar(*str++);
    }
}

char UART2_ReadChar(void)
{
    while(!(USART2->SR & USART_SR_RXNE));

    return USART2->DR;
}

/* =========================================================
   TIM2 DELAY
   ========================================================= */

void TIM2_Init(void);

void delay_us(uint32_t us);

void delay_ms(uint32_t ms);

void TIM2_Init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    /* 16MHz /16 = 1MHz */

    TIM2->PSC = 16 - 1;

    TIM2->CR1 |= TIM_CR1_CEN;
}

void delay_us(uint32_t us)
{
    TIM2->ARR = us;

    TIM2->CNT = 0;

    TIM2->SR = 0;

    while(!(TIM2->SR & TIM_SR_UIF));

    TIM2->SR = 0;
}

void delay_ms(uint32_t ms)
{
    while(ms--)
    {
        delay_us(1000);
    }
}

/* =========================================================
   ADC1
   ========================================================= */

/*void ADC1_Init(void);

uint16_t ADC1_Read(uint8_t channel);

void ADC1_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

     PA3 ANALOG

    //GPIOA->MODER |= (3 << 6);
    GPIOA->MODER |= (3 << 6);    PA3 MQ7

    GPIOA->MODER |= (3 << 14);   PA7 FLOAT SENSOR

    ADC1->CR2 |= ADC_CR2_ADON;
}

uint16_t ADC1_Read(uint8_t channel)
{
    ADC1->SQR3 = channel;

    ADC1->CR2 |= ADC_CR2_SWSTART;

    while(!(ADC1->SR & ADC_SR_EOC));

    return ADC1->DR;
}*/
void ADC1_Init(void);

uint16_t ADC1_Read(uint8_t channel);

void ADC1_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    /* PA4 -> MQ7 ANALOG */

    GPIOA->MODER |= (3 << 8);

    /* PA7 -> FLOAT SENSOR ANALOG */

    GPIOA->MODER |= (3 << 14);

    ADC1->CR2 |= ADC_CR2_ADON;
}

uint16_t ADC1_Read(uint8_t channel)
{
    ADC1->SQR3 = channel;

    ADC1->CR2 |= ADC_CR2_SWSTART;

    while(!(ADC1->SR & ADC_SR_EOC));

    return ADC1->DR;
}
/*

 =========================================================
   I2C1
   =========================================================

void I2C1_Init(void);

void I2C1_Write(uint8_t addr,uint8_t reg,uint8_t data);

uint8_t I2C1_Read(uint8_t addr,uint8_t reg);

void I2C1_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

     PB6 SCL
     PB7 SDA

    GPIOB->MODER &= ~(0xF << 12);

    GPIOB->MODER |=  (0xA << 12);

    GPIOB->OTYPER |= (1 << 6);

    GPIOB->OTYPER |= (1 << 7);

    GPIOB->PUPDR |= (1 << 12);

    GPIOB->PUPDR |= (1 << 14);

    GPIOB->AFR[0] |= (4 << 24);

    GPIOB->AFR[0] |= (4 << 28);

    I2C1->CR2 = 16;

    I2C1->CCR = 80;

    I2C1->TRISE = 17;

    I2C1->CR1 |= I2C_CR1_PE;
}

 =========================================================
   I2C WRITE
   =========================================================

void I2C1_Write(uint8_t addr,uint8_t reg,uint8_t data)
{
    I2C1->CR1 |= I2C_CR1_START;

    while(!(I2C1->SR1 & I2C_SR1_SB));

    I2C1->DR = (addr << 1);

    while(!(I2C1->SR1 & I2C_SR1_ADDR));

    (void)I2C1->SR2;

    I2C1->DR = reg;

    while(!(I2C1->SR1 & I2C_SR1_TXE));

    I2C1->DR = data;

    while(!(I2C1->SR1 & I2C_SR1_TXE));

    I2C1->CR1 |= I2C_CR1_STOP;
}

 =========================================================
   I2C READ
   =========================================================

uint8_t I2C1_Read(uint8_t addr,uint8_t reg)
{
    uint8_t data;

    I2C1->CR1 |= I2C_CR1_START;

    while(!(I2C1->SR1 & I2C_SR1_SB));

    I2C1->DR = (addr << 1);

    while(!(I2C1->SR1 & I2C_SR1_ADDR));

    (void)I2C1->SR2;

    I2C1->DR = reg;

    while(!(I2C1->SR1 & I2C_SR1_TXE));

    I2C1->CR1 |= I2C_CR1_START;

    while(!(I2C1->SR1 & I2C_SR1_SB));

    I2C1->DR = (addr << 1) | 1;

    while(!(I2C1->SR1 & I2C_SR1_ADDR));

    (void)I2C1->SR2;

    while(!(I2C1->SR1 & I2C_SR1_RXNE));

    data = I2C1->DR;

    I2C1->CR1 |= I2C_CR1_STOP;

    return data;
}
*/
/* =========================================================
  I2C1
  ========================================================= */
void I2C1_Init(void);
void I2C1_Write(uint8_t addr,uint8_t reg,uint8_t data);
uint8_t I2C1_Read(uint8_t addr,uint8_t reg);
void I2C1_Init(void)
{
   RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
   RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
   /* PB6 SCL */
   /* PB7 SDA */
   GPIOB->MODER &= ~(0xF << 12);
   GPIOB->MODER |=  (0xA << 12);
   GPIOB->OTYPER |= (1 << 6);
   GPIOB->OTYPER |= (1 << 7);
   GPIOB->PUPDR |= (1 << 12);
   GPIOB->PUPDR |= (1 << 14);
   GPIOB->AFR[0] |= (4 << 24);
   GPIOB->AFR[0] |= (4 << 28);
   I2C1->CR2 = 16;
   I2C1->CCR = 80;
   I2C1->TRISE = 17;
   I2C1->CR1 |= I2C_CR1_PE;
}
/* =========================================================
  I2C WRITE
  ========================================================= */
void I2C1_Write(uint8_t addr,uint8_t reg,uint8_t data)
{
   I2C1->CR1 |= I2C_CR1_START;
   while(!(I2C1->SR1 & I2C_SR1_SB));
   I2C1->DR = (addr << 1);
   while(!(I2C1->SR1 & I2C_SR1_ADDR));
   (void)I2C1->SR2;
   I2C1->DR = reg;
   while(!(I2C1->SR1 & I2C_SR1_TXE));
   I2C1->DR = data;
   while(!(I2C1->SR1 & I2C_SR1_TXE));
   I2C1->CR1 |= I2C_CR1_STOP;
}
/* =========================================================
  I2C READ
  ========================================================= */
uint8_t I2C1_Read(uint8_t addr,uint8_t reg)
{
   uint8_t data;
   I2C1->CR1 |= I2C_CR1_START;
   while(!(I2C1->SR1 & I2C_SR1_SB));
   I2C1->DR = (addr << 1);
   while(!(I2C1->SR1 & I2C_SR1_ADDR));
   (void)I2C1->SR2;
   I2C1->DR = reg;
   while(!(I2C1->SR1 & I2C_SR1_TXE));
   I2C1->CR1 |= I2C_CR1_START;
   while(!(I2C1->SR1 & I2C_SR1_SB));
   I2C1->DR = (addr << 1) | 1;
   while(!(I2C1->SR1 & I2C_SR1_ADDR));
   (void)I2C1->SR2;
   while(!(I2C1->SR1 & I2C_SR1_RXNE));
   data = I2C1->DR;
   I2C1->CR1 |= I2C_CR1_STOP;
   return data;
}
