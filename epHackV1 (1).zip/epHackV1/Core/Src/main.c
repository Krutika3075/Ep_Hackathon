

#include "stm32f407xx.h"
#include <stdio.h>
#include <stdint.h>

/* =========================================================
   CORE
   ========================================================= */

void UART2_Init(void);
void UART2_SendString(char *str);

void TIM2_Init(void);
void delay_ms(uint32_t ms);

void ADC1_Init(void);


//void I2C1_Init(void);
//uint8_t I2C1_Read(uint8_t addr,uint8_t reg);


/* =========================================================
   SENSORS
   ========================================================= */

/* ULTRASONIC */
void Ultrasonic_Init(void);
float Ultrasonic_Read(void);


 //MPU6050
/*
void MPU6050_Init(void);
int16_t MPU6050_ReadAccelX(void);
int16_t MPU6050_ReadAccelY(void);
*/


/* MQ7 */
void MQ7_Init(void);
uint16_t MQ7_Read(void);

//fuel level
void FloatSensor_Init(void);

uint16_t FloatSensor_Read(void);

/* DHT11 */
void DHT11_Init(void);
void DHT11_Read(uint8_t *temp,uint8_t *hum);

/* =========================================================
   ACTUATORS
   ========================================================= */

void Servo_Init(void);
void Servo_SetAngle(uint8_t angle);

void Buzzer_Init(void);
void Buzzer_On(void);
void Buzzer_Off(void);

void LEDs_Init(void);

void Obstacle_LED_ON(void);
void Obstacle_LED_OFF(void);

void Gas_LED_ON(void);
void Gas_LED_OFF(void);

void Environment_LED_ON(void);
void Environment_LED_OFF(void);

void Collision_LED_ON(void);
void Collision_LED_OFF(void);

void Fuel_LED_ON(void);

void Fuel_LED_OFF(void);

/* =========================================================
   COMMUNICATION
   ========================================================= */

void Bluetooth_Init(void);
void Bluetooth_Send(char *str);

/* =========================================================
   VARIABLES
   ========================================================= */

float distance;

int16_t accel_x;
int16_t accel_y;

uint16_t gas_value;
uint16_t fuel_level;

uint8_t dht_temp;
uint8_t dht_hum;

char buffer[120];

/* =========================================================
   MAIN
   ========================================================= */

int main(void)
{
    /* CORE INIT */

    UART2_Init();

    TIM2_Init();

    ADC1_Init();

    //I2C1_Init();

    /* SENSOR INIT */

    Ultrasonic_Init();

    //MPU6050_Init();
    //uint8_t whoami;

  /*  whoami = I2C1_Read(0x68,0x75);

    sprintf(buffer,
            "WHOAMI = 0x%X\r\n",
            whoami);

    UART2_SendString(buffer);

    Bluetooth_Send(buffer);*/

    MQ7_Init();

    FloatSensor_Init();

    DHT11_Init();

    /* ACTUATOR INIT */

    Servo_Init();

    Buzzer_Init();
    LEDs_Init();

    /* COMMUNICATION INIT */

    Bluetooth_Init();

    UART2_SendString("\r\nTESLA VEHICLE SYSTEM STARTED\r\n");

    while(1)
    {
        /* =================================================
           OBSTACLE DETECTION
           ================================================= */

        distance = Ultrasonic_Read();

        sprintf(buffer,
                "Distance = %.2f cm\r\n",
                distance);

        UART2_SendString(buffer);

        Bluetooth_Send(buffer);

        if(distance < 15)
        {
            UART2_SendString("Obstacle Detected\r\n");

            Bluetooth_Send("Obstacle Detected\r\n");

            Servo_SetAngle(90);

            Buzzer_On();
            Obstacle_LED_ON();
        }
        else
        {
            Servo_SetAngle(0);

            Buzzer_Off();
            Obstacle_LED_OFF();
        }

        /* =================================================
           MOTION / COLLISION DETECTION
           =================================================*/

      /*  accel_x = MPU6050_ReadAccelX();

        accel_y = MPU6050_ReadAccelY();

        sprintf(buffer,
                "AX=%d AY=%d\r\n",
                accel_x,
                accel_y);

        UART2_SendString(buffer);

        if(accel_x > 25000 || accel_y > 25000)
        {
            UART2_SendString("Collision Alert\r\n");

            Bluetooth_Send("Collision Alert\r\n");

            Buzzer_On();
            Collision_LED_ON();
        }

        //if(accel_x > 15000 || accel_y > 15000)
        if(accel_x > 7000 || accel_x < -7000 || accel_y > 15000 || accel_y < -15000)
        {
            UART2_SendString("Collision Alert\r\n");

            Bluetooth_Send("Collision Alert\r\n");

            Buzzer_On();

            Collision_LED_ON();
        }
        else
        {
            Collision_LED_OFF();
        }*/
        /* =================================================
           GAS LEAK DETECTION
           ================================================= */

        gas_value = MQ7_Read();

        sprintf(buffer,
                "MQ7 = %d\r\n",
                gas_value);

        UART2_SendString(buffer);

        /*if(gas_value > 7000)
        {
            UART2_SendString("Fuel Leakage Detected\r\n");

            Bluetooth_Send("Fuel Leakage Detected\r\n");

            Buzzer_On();
        }*/
        if(gas_value > 1350)
        {
            UART2_SendString("Fuel Leakage Detected\r\n");

            Bluetooth_Send("Fuel Leakage Detected\r\n");

            Buzzer_On();

            Gas_LED_ON();
        }
        else
        {
            Gas_LED_OFF();
        }
        /* =================================================
           FUEL LEVEL MONITORING
           ================================================= */

        fuel_level = FloatSensor_Read();

        sprintf(buffer,
                "Fuel Level = %d\r\n",
                fuel_level);

        UART2_SendString(buffer);

        Bluetooth_Send(buffer);

        /* FULL TANK */

        if(fuel_level > 500)
        {
            UART2_SendString("Fuel Tank Full\r\n");

            Bluetooth_Send("Fuel Tank Full\r\n");

            Fuel_LED_OFF();

            Buzzer_Off();
        }

        /* LOW FUEL */

        else if(fuel_level > 250 && fuel_level <= 500)
        {
            UART2_SendString("Fuel Level Low\r\n");

            Bluetooth_Send("Fuel Level Low\r\n");

            Fuel_LED_ON();

            Buzzer_Off();
        }

        /* CRITICAL LOW */

        else
        {
            UART2_SendString("Critical Fuel Level\r\n");

            Bluetooth_Send("Critical Fuel Level\r\n");

            Fuel_LED_ON();

            Buzzer_On();
        }
       /*  =================================================
           FUEL LEVEL MONITORING
           =================================================

        fuel_level = FloatSensor_Read();

        sprintf(buffer,
                "Fuel Level = %d\r\n",
                fuel_level);

        UART2_SendString(buffer);

        Bluetooth_Send(buffer);

         FULL TANK

        if(fuel_level > 3500)
        {
            UART2_SendString("Fuel Tank Full\r\n");

            Bluetooth_Send("Fuel Tank Full\r\n");

            Gas_LED_OFF();

            Buzzer_Off();
        }

         LOW FUEL

        else if(fuel_level > 1500 && fuel_level <= 3500)
        {
            UART2_SendString("Fuel Level Low\r\n");

            Bluetooth_Send("Fuel Level Low\r\n");

            Gas_LED_ON();

            Buzzer_Off();
        }

         CRITICAL

        else
        {
            UART2_SendString("Critical Fuel Level\r\n");

            Bluetooth_Send("Critical Fuel Level\r\n");

            Gas_LED_ON();

            Buzzer_On();
        }*/

        /* =================================================
           ENVIRONMENT MONITORING
           ================================================= */

        DHT11_Read(&dht_temp,&dht_hum);

        sprintf(buffer,
                "TEMP=%dC HUM=%d%%\r\n",
                dht_temp,
                dht_hum);

        UART2_SendString(buffer);

        Bluetooth_Send(buffer);

        /*if(dht_temp > 45)
        {
            UART2_SendString("High Cabin Temperature\r\n");

            Bluetooth_Send("High Cabin Temperature\r\n");

            Buzzer_On();
        }
*/
        if(dht_temp > 36)
        {
            UART2_SendString("High Cabin Temperature\r\n");

            Bluetooth_Send("High Cabin Temperature\r\n");

            Buzzer_On();

            Environment_LED_ON();
        }
        else
        {
            Environment_LED_OFF();
        }
        delay_ms(1000);
    }
}
