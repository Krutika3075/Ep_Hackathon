
#include "stm32f407xx.h"
#include <stdint.h>

void delay_ms(uint32_t ms);

void delay_us(uint32_t us);

/* =========================================================
   EXTERNAL FUNCTIONS
   ========================================================= */

void delay_us(uint32_t us);

uint16_t ADC1_Read(uint8_t channel);

void I2C1_Write(uint8_t addr,uint8_t reg,uint8_t data);

uint8_t I2C1_Read(uint8_t addr,uint8_t reg);

/* =========================================================
   ULTRASONIC
   ========================================================= */

void Ultrasonic_Init(void);
float Ultrasonic_Read(void);

void Ultrasonic_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    /* PA0 -> TRIG */

    GPIOA->MODER &= ~(3<<0);
    GPIOA->MODER |=  (1<<0);

    /* PA1 -> ECHO */

    GPIOA->MODER &= ~(3<<2);
}

float Ultrasonic_Read(void)
{
    uint32_t time = 0;

    GPIOA->ODR &= ~(1<<0);

    delay_us(2);

    GPIOA->ODR |= (1<<0);

    delay_us(10);

    GPIOA->ODR &= ~(1<<0);

    while(!(GPIOA->IDR & (1<<1)));

    while(GPIOA->IDR & (1<<1))
    {
        time++;
    }

    return (time * 0.034)/2;
}

/* =========================================================
   MQ7
   ========================================================= */

void MQ7_Init(void);
uint16_t MQ7_Read(void);

void MQ7_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    GPIOA->MODER |= (3<<8);
}

uint16_t MQ7_Read(void)
{
    return ADC1_Read(4);
}

/* =========================================================
   FLOAT SENSOR
   ========================================================= */

void FloatSensor_Init(void);

uint16_t FloatSensor_Read(void);

void FloatSensor_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    /* PA7 ANALOG */

    GPIOA->MODER |= (3<<14);
}

uint16_t FloatSensor_Read(void)
{
    return ADC1_Read(7);
}

/* =========================================================
   DHT11
   ========================================================= */
/* =========================================================
   DHT11
   PA5
   ========================================================= */

void DHT11_Init(void);

void DHT11_Read(uint8_t *temp,uint8_t *hum);

static void DHT11_SetOutput(void);

static void DHT11_SetInput(void);

static uint8_t DHT11_CheckResponse(void);

static uint8_t DHT11_ReadByte(void);

/* ========================================================= */

void DHT11_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
}

/* ========================================================= */

static void DHT11_SetOutput(void)
{
    GPIOA->MODER &= ~(3<<10);

    GPIOA->MODER |= (1<<10);
}

/* ========================================================= */

static void DHT11_SetInput(void)
{
    GPIOA->MODER &= ~(3<<10);
}

/* ========================================================= */

static uint8_t DHT11_CheckResponse(void)
{
    uint8_t response = 0;

    delay_us(40);

    if(!(GPIOA->IDR & (1<<5)))
    {
        delay_us(80);

        if(GPIOA->IDR & (1<<5))
        {
            response = 1;
        }
    }

    while(GPIOA->IDR & (1<<5));

    return response;
}

/* ========================================================= */

static uint8_t DHT11_ReadByte(void)
{
    uint8_t i;
    uint8_t byte = 0;

    for(i=0;i<8;i++)
    {
        while(!(GPIOA->IDR & (1<<5)));

        delay_us(40);

        if(GPIOA->IDR & (1<<5))
        {
            byte |= (1<<(7-i));
        }

        while(GPIOA->IDR & (1<<5));
    }

    return byte;
}

/* ========================================================= */

void DHT11_Read(uint8_t *temp,uint8_t *hum)
{
    uint8_t Rh_byte1;
    uint8_t Rh_byte2;

    uint8_t Temp_byte1;
    uint8_t Temp_byte2;

    uint8_t checksum;

    DHT11_SetOutput();

    GPIOA->ODR &= ~(1<<5);

    delay_ms(20);

    GPIOA->ODR |= (1<<5);

    delay_us(30);

    DHT11_SetInput();

    if(DHT11_CheckResponse())
    {
        Rh_byte1   = DHT11_ReadByte();

        Rh_byte2   = DHT11_ReadByte();

        Temp_byte1 = DHT11_ReadByte();

        Temp_byte2 = DHT11_ReadByte();

        checksum   = DHT11_ReadByte();

        *hum  = Rh_byte1;

        *temp = Temp_byte1;
    }
}

/*
void DHT11_Init(void);
void DHT11_Read(uint8_t *temp,uint8_t *hum);

void DHT11_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    GPIOA->MODER &= ~(3<<10);

    GPIOA->MODER |= (1<<10);
}

void DHT11_Read(uint8_t *temp,uint8_t *hum)
{
    *temp = 30;

    *hum = 65;
}
*/

/* =========================================================
   MPU6050
   ========================================================= */
/* =========================================================
   MPU6050
   ========================================================= */
/*
void MPU6050_Init(void);

int16_t MPU6050_ReadAccelX(void);

int16_t MPU6050_ReadAccelY(void);

void MPU6050_Init(void)
{
    delay_ms(100);

     WAKE MPU6050

    I2C1_Write(0x68,0x6B,0x00);

    delay_ms(100);
}

int16_t MPU6050_ReadAccelX(void)
{
    uint8_t high;
    uint8_t low;

    high = I2C1_Read(0x68,0x3B);

    delay_us(50);

    low  = I2C1_Read(0x68,0x3C);

    return (int16_t)((high << 8) | low);
}

int16_t MPU6050_ReadAccelY(void)
{
    uint8_t high;
    uint8_t low;

    high = I2C1_Read(0x68,0x3D);

    delay_us(50);

    low  = I2C1_Read(0x68,0x3E);

    return (int16_t)((high << 8) | low);
}*/

void MPU6050_Init(void);

int16_t MPU6050_ReadAccelX(void);

int16_t MPU6050_ReadAccelY(void);

void MPU6050_Init(void)
{
    I2C1_Write(0x68,0x6B,0x00);
}

int16_t MPU6050_ReadAccelX(void)
{
    uint8_t high;
    uint8_t low;

    high = I2C1_Read(0x68,0x3B);

    low  = I2C1_Read(0x68,0x3C);

    return ((high << 8) | low);
}

int16_t MPU6050_ReadAccelY(void)
{
    uint8_t high;
    uint8_t low;

    high = I2C1_Read(0x68,0x3D);

    low  = I2C1_Read(0x68,0x3E);

    return ((high << 8) | low);
}

